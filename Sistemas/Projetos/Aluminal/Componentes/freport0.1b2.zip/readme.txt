FortesReport

INSTALATION
-----------

The instalation must be made manualy simple copying the files info the folder
(DELPHI)\Projects\Bpl. If you do wish to install in another folder, remember to
add it to the Delphi searchpath (Menu: Tools - Environment Options - Library - Library path)
After that, add the package bplRLibDelphi7vcl.bpl to Kylix
(Menu: Component - Install Packages...)


Fortes Inform�tica Ltda
R. Antonio Fortes, 330  �gua Fria
CEP 60813-630
Fortaleza - CE - Brasil
PABX: 55(85)278-1122

Internet
http://www.fortesinformatica.com.br
rlib@grupofortes.com.br
